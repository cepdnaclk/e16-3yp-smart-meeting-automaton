import React from "react";

function Mainbar() {
  return <div></div>;
}

export default Mainbar;
