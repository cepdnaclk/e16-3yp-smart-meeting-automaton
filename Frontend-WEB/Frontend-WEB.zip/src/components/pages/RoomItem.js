import React from "react";

const RoomItem = (props) => {
  const { roomName, roomStatus, activeTime, meetingName, meetingOwner } = props;
  return <div></div>;
};

export default RoomItem;
