export const lecRoomData = [
  { id: 1, name: "Lecture Room 1" },
  { id: 2, name: "Seminar Room 2" },
  { id: 3, name: "Lecture 14" },
  { id: 4, name: "Lecture Room 4" },
];
