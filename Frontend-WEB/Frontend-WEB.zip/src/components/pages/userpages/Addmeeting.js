import React from "react";

export const Addmeeting = () => {
  return (
    <div>
      <h1>ADD MEETINGS</h1>
    </div>
  );
};

export default Addmeeting;
