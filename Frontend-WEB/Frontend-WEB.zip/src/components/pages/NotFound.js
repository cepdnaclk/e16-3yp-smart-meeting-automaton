import React from "react";

export const NotFound = () => {
  return (
    <div>
      <h1>404!</h1>
      <h2>Not Found</h2>
      <h2>WE ARE SORRY.</h2>
      <p className="my-1">This is 3rd year Embedded Project</p>
      <p className="bg-dark p">
        <strong>SMA Version: </strong> 1.0.0
      </p>
    </div>
  );
};

export default NotFound;
